# Addresses of SEP20 tokens and DApps
The [tokens.json](https://github.com/sep20tokens/sep20tokens.github.io/blob/main/tokens.json) file lists the details of SEP20 tokens, including symbol, address, decimals and URL. It's content can be viewed [in a web page](https://sep20tokens.github.io).

The [apps.json](https://github.com/sep20tokens/sep20tokens.github.io/blob/main/apps.json) file lists the URLs and addresses of some DApps. It's content can be viewed [in a web page](https://sep20tokens.github.io/app.html).

Please feel free to modify these files and submit pull requests to us.
